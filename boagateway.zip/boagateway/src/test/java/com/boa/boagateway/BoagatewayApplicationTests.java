package com.boa.boagateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoagatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
