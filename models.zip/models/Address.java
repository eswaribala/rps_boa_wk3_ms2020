package com.boa.customerapi.models;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name="BOA_Address")
@Data
public class Address {
	
	@Column(name="Door_No",nullable = false, length = 5)
	private String doorNo;
	@Column(name="Street",nullable = false, length = 150)
	private String street;
	@Column(name="City", nullable = false, length = 150)
	private String city;
	@Column(name="State", nullable = false, length = 150)
	private String state;
	@ManyToOne(cascade = CascadeType.MERGE,fetch = FetchType.LAZY)
	@JoinColumn(name = "Customer_Id")
	private Customer customer;
	

}
