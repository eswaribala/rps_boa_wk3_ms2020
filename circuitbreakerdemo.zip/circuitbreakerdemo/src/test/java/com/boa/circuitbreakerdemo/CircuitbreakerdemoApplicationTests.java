package com.boa.circuitbreakerdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CircuitbreakerdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
