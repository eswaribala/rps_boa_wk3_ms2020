package com.boa.customerapi.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boa.customerapi.models.Customer;
import com.boa.customerapi.repositories.CustomerRepository;

@Service
public class CustomerService {
    @Autowired
	private CustomerRepository customerRepository;
    
    //insert operation
    
    public Customer saveCustomer(Customer customer)
    {
    	if( customer.getAddressList().size() > 0 )
        {
            customer.getAddressList().stream().forEach( address -> {
                address.setCustomer(customer);
            } );
        }
    	return this.customerRepository.save(customer);
    }
    
    //findall
    public List<Customer> fetchAllCustomers()
    {
    	return this.customerRepository.findAll();
    }
    
    //find customer by Id
    
    public Customer findCustomerById(long customerId)
    {
    	return this.customerRepository.findById(customerId).orElse(null);
    }
    
    //delete customer by id
    
    public boolean deleteCustomerById(long customerId)
    {
    	boolean status=false;
    	this.customerRepository.deleteById(customerId);
    	Customer customer = findCustomerById(customerId);
    	if (customer==null)
    		status=true;
    	return status;
    }
    
	//update customer 
    //must pass customer id
    public Customer updateCustomer(Customer customer)
    {
    	return this.customerRepository.save(customer);
    }
    
}
