## Versioning REST API with Spring Boot and Swagger

Detailed description can be found here: [Versioning REST API with Spring Boot and Swagger](https://piotrminkowski.wordpress.com/2018/02/19/versioning-rest-api-with-spring-boot-and-swagger/) 