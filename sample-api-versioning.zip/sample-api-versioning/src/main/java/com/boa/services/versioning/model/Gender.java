package com.boa.services.versioning.model;

public enum Gender {

	MALE, FEMALE;
	
}
