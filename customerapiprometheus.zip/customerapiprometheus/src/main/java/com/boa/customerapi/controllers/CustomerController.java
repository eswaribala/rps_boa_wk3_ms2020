package com.boa.customerapi.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.boa.customerapi.models.Customer;
import com.boa.customerapi.services.CustomerService;

@RestController
public class CustomerController {
    @Autowired
	private CustomerService customerService;
    
    //customers post
    @CrossOrigin("*")
    @PostMapping("/customers")
    @ResponseBody
    public ResponseEntity<?> addCustomer(@Valid @RequestBody Customer customer)
    {
    	Customer customerObj=this.customerService.saveCustomer(customer);
    	if(customerObj==null)
    	 	return ResponseEntity.status(HttpStatus.BAD_REQUEST).
    				body("Customer Json not Valid or DB Connection error");
    	
    	else
    		return  ResponseEntity.status(HttpStatus.ACCEPTED).
    				body(customerObj);
    	
    }
    
    @CrossOrigin("*")
    @GetMapping("/customers")
    public List<Customer> getAllCustomers()
    {
    	return this.customerService.fetchAllCustomers();
    	
    }
    
    @CrossOrigin("*")
    @GetMapping("/customers/{customerId}")
    public Customer getCustomerById(@PathVariable("customerId") long customerId)
    {
    	return this.customerService.findCustomerById(customerId);
    	
    }
    
    @CrossOrigin("*")
    @DeleteMapping("/customers/{customerId}")
    public ResponseEntity<String> deleteCustomerById(@PathVariable("customerId") long customerId)
    {
    	 boolean status=this.customerService.deleteCustomerById(customerId);
    	 if(status)
    		 return ResponseEntity.status(HttpStatus.ACCEPTED)
    				 .body("Customer Instance-->"+customerId+"Deleted");
    	 else
    		 return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED)
    				 .body("Customer Instance-->"+customerId+"could not be deleted");
    	 
    	
    }
    
    @CrossOrigin("*")
    @PutMapping("/customers") //existing customer id mandatory
    public ResponseEntity<?> updateCustomer(@RequestBody Customer customer)
    {
    	Customer customerObj=this.customerService.saveCustomer(customer);
    	if(customerObj==null)
    	 	return ResponseEntity.status(HttpStatus.BAD_REQUEST).
    				body("Customer Json not Valid or DB Connection error");
    	
    	else
    		return  ResponseEntity.status(HttpStatus.ACCEPTED).
    				body(customerObj);
    	
    	
    }
	
}
