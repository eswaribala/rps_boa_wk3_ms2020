package com.boa.customerapi.models;

public enum GenderType {
  MALE,FEMALE,TRANSGENDER
}
